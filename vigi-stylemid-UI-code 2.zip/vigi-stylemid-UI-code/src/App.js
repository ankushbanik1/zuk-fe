import LaunchApp from './Constants/LaunchApp';
// import GetOutfitForm from './Constants/GetOutfitForm';
import './App.css';

function App() {
  return (
    <div className="App">
      <LaunchApp />
      {/* <GetOutfitForm /> */}
    </div>
  );
}

export default App;
