import React, { useState, useEffect } from "react";
import { Check } from "lucide-react"; // Assuming you're using lucide-react for the Check icon

const TimerComponent = () => {
  const [timer, setTimer] = useState(50);

  useEffect(() => {
    if (timer > 0) {
      const interval = setInterval(() => {
        setTimer((prev) => prev - 1);
      }, 1000);

      return () => clearInterval(interval); // Clear the interval when the component unmounts
    }
  }, [timer]);

  return (
    <div className="text-center p-8 space-y-6 animate-fadeIn">
      <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce">
        <Check className="w-8 h-8 text-purple-500" />
      </div>
      <h2 className="text-2xl font-semibold animate-slideInBottom">
        Perfect! We've got your style preferences
      </h2>
      <p
        className="text-gray-600 animate-slideInBottom"
        style={{ animationDelay: "200ms" }}
      >
        We'll use your selections to curate a personalized style collection just
        for you. Just a moment...
      </p>
      <p className="text-lg font-medium text-purple-600">
        {timer > 0
          ? `Your collection will be ready in ${timer} seconds.`
          : "Your collection is ready!"}
      </p>
    </div>
  );
};

export default TimerComponent;
