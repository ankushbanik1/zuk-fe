import React from 'react';
// import { FaFacebookF, FaTwitter, FaInstagram, FaLinkedinIn } from 'react-icons/fa';

const Footer = () => {

  return (
    <>
      <footer>
        <div className="container mx-auto">
          {/* Footer Bottom */}
          <div className="mt-12 border-t border-gray-700 pt-6 flex flex-col md:flex-row justify-between items-center text-sm text-gray-500">
            <p>&copy; {new Date().getFullYear()} Zukino StyleMind. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </>
  );
};


export default Footer;