import React, { useEffect, useState } from "react";

const FinalImageGallery = ({ imageGallery }) => {
  const [filteredImages, setFilteredImages] = useState([]);
  // State to manage image loading errors
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    if (imageGallery && imageGallery.data) {
      console.log("Image Gallery updated:", imageGallery.data);

      // Filter out images without URLs
      const validImages = imageGallery.data.filter((image) => image.url);
      // Exclude the last image if needed
      setFilteredImages(validImages);
    } else {
      setFilteredImages([]); // Reset if no data
    }
  }, [imageGallery]); // Runs whenever imageGallery changes

  const renderImageGallery = () => {
    if (!filteredImages || filteredImages.length === 0) {
      return (
        <div className="flex flex-col items-center justify-center p-6">
          <h2 className="text-3xl font-bold mb-10 text-white-500">Oops! No images found</h2>
          <p className="text-white-500">
            It looks like we don't have any images to show right now. Try refreshing the page or check back later!
          </p>
        </div>
      );
    }

    return (
      <div className="grid grid-cols-2 gap-4 md:grid-cols-2 lg:grid-cols-2 p-4">
        {filteredImages.map((image, index) => {
          // Append a timestamp to the image URL to prevent caching
          const imageUrl = `${image.url}?timestamp=${image.timestamp}`;
          return (
            <div
              className="relative group rounded-lg shadow-lg overflow-hidden transform transition-transform hover:scale-105"
              key={index}
            >
              <div className="flex items-center justify-center w-full h-full">
                {hasError ? (
                  <img
                  className="object-cover object-center w-full h-full"
                  src={image.url}
                  alt={image.id || "Untitled Image"} // Set error state on image load failure
                />
                ) : (
                  <img
                    className="object-cover object-center w-full h-full"
                    src={imageUrl}
                    alt={image.id || "Untitled Image"}
                    onError={() => setHasError(true)} // Set error state on image load failure
                  />
                )}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  return renderImageGallery();
};

export default FinalImageGallery;