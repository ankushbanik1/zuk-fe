// import './App.css';
// import Navbar from '../components/Navbar'
// import Footer from '../components/Footer';
import NewDynamicForm from './NewDynamicForm';
import IntroScreen from '../components/IntroScreen'
import {AnimatePresence} from "framer-motion";
import React, { useState } from 'react';
import Footer from '../components/Footer';


function LaunchApp() {
  const [isIntroVisible, setIsIntroVisible] = useState(true);

  const handleLaunch = () => {
    setIsIntroVisible(false);
  };

  return (
    <section id="launch-app" className='bg-gradient-to-br from-purple-100 to-blue-100'>
      <AnimatePresence>
        {isIntroVisible ? (
          <IntroScreen onLaunch={handleLaunch} key="intro" />
        ) : (
          <NewDynamicForm key="form" />
        )}
      </AnimatePresence>
      <Footer/>
    </section>
  );
};

export default LaunchApp;
