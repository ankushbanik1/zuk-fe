import DynamicForm from './DynamicForm';
import IntroScreen from '../components/IntroScreen'
import { AnimatePresence } from 'framer-motion';
import React, { useState } from 'react';


function GetOutfit() {
  const [isIntroVisible, setIsIntroVisible] = useState(true);

  const handleLaunch = () => {
    setIsIntroVisible(false);
  };

  return (
    <section id="get-outfit">
      <AnimatePresence>
          <DynamicForm key="form" />
      </AnimatePresence>
    </section>
  );
};

export default GetOutfit;
