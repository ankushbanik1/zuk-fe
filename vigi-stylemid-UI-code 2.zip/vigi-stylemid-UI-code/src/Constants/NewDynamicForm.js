import React, { useState } from 'react';
import { ChevronRight, ChevronLeft, Check, MapPin, User, HeartHandshake, Sparkles } from 'lucide-react';
import axios from 'axios';
import { FaUpload, FaTimesCircle } from 'react-icons/fa';
import GetOutfitForm from './GetOutfitForm';
import FinalImageGallery from '../components/FinalImageGallery';
import TimerComponent from '../components/TimerComponent';


const questions = [
  {
    question: "How would you describe your body shape?",
    subtext: "This helps us recommend fits that look amazing on you!",
    type: "options",
    icon: <User className="w-6 h-6" />,
    options: [
      { label: "Slim", value: "Slim & Straight", icon: "🏃‍♂️🧍‍♀️✨" },
      { label: "Athletic", value: "Athletic", icon: "💪🏋️‍♂️🏃‍♀️" },
      { label: "Curvy", value: "Curvy", icon: "🍑👗💃" },
      { label: "Hourglass", value: "Hourglass", icon: "⏳✨" },
    ],
  },
  {
    question: "What's the occasion?",
    subtext: "We want your outfit to fit the moment perfectly",
    type: "options",
    icon: <HeartHandshake className="w-6 h-6" />,
    options: [
      { label: "Casual Day Out", value: "Casual Day Out", icon: "👜👟" },
      { label: "Evening/Party", value: "Evening/Party", icon: "🎉" },
      { label: "Active/Sports", value: "Active/Sports", icon: "🏃" },
      { label: "Vacation", value: "Vacation", icon: "✈️" },
    ],
  },
  {
    question: "How would you define your style vibe?",
    subtext: "The right style vibe makes all the difference",
    type: "options",
    icon: <HeartHandshake className="w-6 h-6" />,
    // options: ["Relaxed Fit", "Tailored Fit", "Oversized Fit", "Snug Fit", "Regular Fit", "Flared & Flowing"],
    options: [
      { label: "Adventure", icon: "⛺🎒🥾", value: "Adventure" },
      { label: "Techie", icon: "💻🤖📱", value: "Techie" },
      { label: "Street wear", icon: "🧢👟🕶️", value: "Street wear" },
      { label: "Leave it on us", icon: "🎭🎨✨", value: "explore" },
    ],    
  },
  {
    question: "Where's your next style destination?",
    subtext: "Tell us where you'll be rocking this look.",
    type: "options",
    icon: <MapPin className="w-6 h-6" />,
    options: [
      { label: "Beach", icon: "🏖️🌊☀️", value: "Beach" },
      { label: "Mountain", value: "Mountain", icon: "🏔️🥾🌲" },
      { label: "Desert", value: "Desert", icon: "🏜️🌵" },
      { label: "City", icon: "🌆🚖🏙️", value: "City" },
    ],
  },
  {
    question: "Choose an image that represents your best self. Don't worry; it's just between us",
    type: "file",
  },
  {
    question: "Please enter your name.",
    type: "text",
  },
  {
    question: "Enter your Contact Number",
    type: "contact",
  },
];

const FloatingEmoji = ({ emoji, style }) => (
  <div
    className="absolute animate-float opacity-20 pointer-events-none"
    style={style}
  >
    {emoji}
  </div>
);

const NewDynamicForm = () => {
 
  const Client_App_Images_Url=process.env.REACT_APP_Client_App_Images_Url
  const Get_Image_Urls=process.env.REACT_APP_Get_Image_Urls
  const Client_Id=process.env.REACT_APP_Client_Id
  const STYLEMIND_API_KEY=process.env.REACT_APP_STYLEMIND_API_KEY


  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [selectedOption, setSelectedOption] = useState(null);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [floatingEmojis, setFloatingEmojis] = useState([]);
  const isAnswered = answers[currentQuestion];
  const [isLoading, setIsLoading] = useState(false);
  // const [fetchedImages, setFetchedImages] = useState([]);
  const [loadedImages, setloadedImages] = useState(false);
  const [imageGallery, setImageGallery] = useState([]);
  const [imageUrls, setimageUrls] = useState([]);

  // const [isIntroVisible, setIsIntroVisible] = useState(true);

  // const handleLaunch = () => {
  //   setIsIntroVisible(false);
  // };

  const handleAnswerChange = (e) => {
    const value = e.target.type === "file" ? e.target.files[0] : e.target.value;
    setAnswers({
      ...answers,
      [currentQuestion]: value,
    });
  };

  const handleRemoveImage = () => {
    setAnswers({
      ...answers,
      [currentQuestion]: null,
    });
  };

  const addFloatingEmoji = (emoji) => {
    const newEmoji = {
      id: Date.now(),
      emoji,
      style: {
        left: `${Math.random() * 80 + 10}%`,
        top: `${Math.random() * 80 + 10}%`,
        fontSize: `${Math.random() * 20 + 20}px`,
        animation: `float ${Math.random() * 3 + 2}s linear infinite`,
      }
    };
    setFloatingEmojis(prev => [...prev, newEmoji]);
    setTimeout(() => {
      setFloatingEmojis(prev => prev.filter(e => e.id !== newEmoji.id));
    }, 3000);
  };

  const handleOptionClick = (value, icon) => {
    setSelectedOption(value);
    setAnswers({ ...answers, [currentQuestion]: value });
    addFloatingEmoji(icon);
   
    setTimeout(() => {
      if (currentQuestion < questions.length - 1) {
        setIsTransitioning(true);
        setTimeout(() => {
          setCurrentQuestion(currentQuestion + 1);

          setSelectedOption(null);
          setIsTransitioning(false);
        }, 500);
      } else {
        setSubmitted(true);
        handleSubmit();
      }
    }, 800);
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setIsTransitioning(true);
      setTimeout(() => {
        setCurrentQuestion(currentQuestion - 1);
        setSelectedOption(answers[currentQuestion - 1] || null);

        setIsTransitioning(false);
      }, 500);
    }
  };
  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      // setDirection(1);
      setCurrentQuestion(currentQuestion + 1);
    } else {
      handleSubmit(); // Call the submit function on the last question
    }
  };

  const getBackgroundColor = () => {
    const season = answers[2];
    const selectedOption = questions[2]?.options.find(opt => opt.value === season);
    return selectedOption?.bgClass || "from-purple-100 to-blue-100";
  };
  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  // country, bodyType, season, eventType, preferredStyle, fitPreference, destinationPlace, colorPreference, name, email, client_id, user_phone_number
  const formDataQuestions = ["bodyType", "eventType", "styleVibe", "destinationPlace","file", "name", "user_phone_number"]
  // const formDataQuestions = ["bodyType", "eventType", "fitPreference", "destinationPlace","file", "name", "user_phone_number"]
  const handleSubmit = async () => {
    setIsLoading(true);
    const formData = new FormData();
    Object.keys(answers).forEach((key) => {
      const answer = answers[key];
      formData.append(formDataQuestions[key], answer);
    });
    formData.append("client_id", Client_Id);


    try {
      const response = await axios.post(
        Client_App_Images_Url,
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
            'STYLEMIND-API-KEY': STYLEMIND_API_KEY, // Example for custom header key
          },
        }
      );
      if (response.status === 204) {
        // setSubmitted(true);
        alert("Your outfit generation limit is over. Please contact us at founders@stylemind.zukino.co.in for more searches.");
        return;
      }
      if (response.status >= 200 && response.status < 300) {
        const image_urls = []
        // Success
        const { request_id } = response.data;
        console.log(request_id);
        setSubmitted(true);
        await sleep(50000)
        const imagesResponse = await axios.get(`${Get_Image_Urls}/${request_id}`);
        // console.log("imagesResponse", imagesResponse)
        if (imagesResponse.status >= 200 && imagesResponse.status < 300) {
          setImageGallery([])
          setImageGallery(imagesResponse);
          // Success
          setloadedImages(true)

          imagesResponse?.data.forEach((image, index) => {
            image_urls[index] = image.url;
          });
          setimageUrls(image_urls || []);
          // console.log(image_urls);

        }
        // console.log("Request ID:", request_id);
      } else if (response.status >= 400 && response.status < 500) {
        // Client error
        console.error("Client error:", response.status, response.statusText);
      } else if (response.status >= 500) {
        // Server error
        console.error("Server error:", response.status, response.statusText);
      } else {
        // Other responses
        console.warn("Unexpected response:", response.status, response.statusText);
      }
    } catch (error) {
      alert("Bad Network! Unable to Submit, Try again later.");
      console.error('Error submitting form:', error);
    }finally {
      setIsLoading(false); // Hide loader
    }
  };

  const renderInputField = () => {
    const current = questions[currentQuestion];
    if (current.type === "options") {
      return (
        <div className="grid grid-cols-2 gap-4">
          {questions[currentQuestion].options.map((option, index) => {

            const isSelected = selectedOption === option.value;
            return (
              <button
                key={index}
                onClick={() => handleOptionClick(option.value, option.icon)}

                className={`group relative p-6 rounded-xl shadow-sm
                  ${isSelected
                    ? 'bg-purple-100 ring-2 ring-purple-500 animate-pulse'
                    : 'bg-gray-50 hover:bg-gray-100'
                  }
                  transition-all duration-300 transform hover:scale-105 hover:shadow-md
                  ${index % 2 === 0 ? 'animate-slideInLeft' : 'animate-slideInRight'}`}
                style={{
                  animationDelay: `${index * 100}ms`,
                }}
              >
                <div className="text-center space-y-3">
                  <div className={`text-4xl mb-2 transform transition-transform duration-300 ${
                    isSelected ? 'scale-110' : 'group-hover:scale-110'
                  }`}>
                    {option.icon}
                  </div>
                  <span className="text-sm font-medium">{option.label}</span>

                  {isSelected && (
                    <div className="absolute top-2 right-2 animate-fadeIn">
                      <Check className="w-5 h-5 text-purple-500" />
                    </div>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      );
    } else if (current.type === "text") {
      return (
        <div className='flex justify-spacebetween items-center mt-6'>
          <input
            type="text"
            value={answers[currentQuestion] || ""}
            onChange={handleAnswerChange}
            className="px-4 py-3 rounded-lg border border-blue-100 focus:border-purple-300 transition-all duration-300 focus:outline-none shadow-md hover:shadow-lg w-full"
            placeholder="Type your answer"
          />
          <button
            onClick={handleNext}
            disabled={!isAnswered}
            className={`flex items-center gap-2 px-4 py-2 m-4 rounded-lg transition-all duration-300
              ${currentQuestion === 0 && isAnswered
                ? 'text-gray-300 cursor-not-allowed'
                : 'text-gray-600 hover:bg-gray-100 hover:scale-105'}`}
          >
            {currentQuestion < questions.length - 1 ? "Next" : "Submit"}
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      );
    } else if (current.type === "contact") {
      return (
        <div className='flex justify-spacebetween items-center mt-6'>
          <input
            type="text"
            value={answers[currentQuestion] || ""}
            onChange={handleAnswerChange}
            className="px-4 py-3 rounded-lg border border-blue-100 focus:border-purple-300 transition-all duration-300 focus:outline-none shadow-md hover:shadow-lg w-full"
            placeholder="919XXXXXXXXX"
          />
          <button
            onClick={handleNext}
            disabled={!isAnswered}
            className={`flex items-center gap-2 px-4 py-2 m-4 rounded-lg transition-all duration-300
              ${currentQuestion === 0 && isAnswered
                ? 'text-gray-300 cursor-not-allowed'
                : 'text-gray-600 hover:bg-gray-100 hover:scale-105'}`}
          >
            {currentQuestion < questions.length - 1 ? "Next" : "Submit"}
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      );
    } else if (current.type === "file") {
        return (
          <div className="flex flex-col items-center space-y-4">
            <h2 className="text-lg text-center text-white-100 mb-4">
              *Kindly upload an image that contains only yourself, in either JPG/JPEG or PNG format.
            </h2>
            <label className="cursor-pointer flex items-center space-x-2 px-4 py-3 rounded-lg bg-gray-800 text-white border border-purple-500 shadow-md hover:shadow-lg transition-all duration-300">
              <FaUpload className="text-xl" />
              <span>Upload Image</span>
              <input
                type="file"
                onChange={handleAnswerChange}
                className="hidden"
                accept="image/*"
              />
            </label>
            {answers[currentQuestion] && (
              <div className="relative">
                <img
                  src={URL.createObjectURL(answers[currentQuestion])}
                  alt="Preview"
                  className="w-40 h-40 object-cover rounded-lg shadow-md"
                />
                <button
                  onClick={handleRemoveImage}
                  className="absolute top-1 right-1 text-red-500 text-lg hover:text-red-700 focus:outline-none"
                >
                  <FaTimesCircle />
                </button>
                <div className="cursor-pointer flex justify-centre space-x-2 px-4 py-3 rounded-lg">                  
                  <button
                    onClick={handleNext}
                    disabled={!isAnswered}
                    // isAnswered
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-300
                      ${currentQuestion === 0 && isAnswered
                        ? 'text-gray-300 cursor-not-allowed'
                        : 'text-gray-600 hover:bg-gray-100 hover:scale-105'}`}
                  >
                    Next
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        );
      }
  };

  
  // const renderImageGallery = () => {
  //   if (!imageGallery || imageGallery.length === 0) {
  //     return (
  //       <div className="flex flex-col items-center justify-center p-6">
  //         <h2 className="text-3xl font-bold mb-10 text-white-500">Oops! No images found</h2>
  //         <p className="text-white-500">
  //           It looks like we don't have any images to show right now. Try refreshing the page or check back later!
  //         </p>
  //       </div>
  //     );
  //   }
  
  //   return (
  //     <div className="grid grid-cols-2 gap-4 md:grid-cols-2 lg:grid-cols-2 p-4">
  //       {imageGallery?.data.slice(0, -1).map((image, index) => {
  //         const imageUrl = `${image.url}?timestamp=${new Date().getTime()}`;
  //         console.log(`Rendering Image ${index}: ${imageUrl}`);
  
  //         return (
  //           <div
  //             className="relative group rounded-lg shadow-lg overflow-hidden transform transition-transform hover:scale-105"
  //             key={index}
  //           >
  //             <div className="flex items-center justify-center w-full h-full">
  //               <img
  //                 className="object-cover object-center w-full h-full"
  //                 src={image.url || "default-thumbnail.jpg"}
  //                 // src={image.url || "default-thumbnail.jpg"}
  //                 alt={image.id || "Untitled Image"}
  //               />
  //             </div>
  //           </div>
  //         );
  //       })}
  //     </div>
  //   );
  // };
  

  // const renderImageGallery = () => {
    
  //   if (!imageGallery || imageGallery.length === 0) {
  //     return (
  //       <div className="flex flex-col items-center justify-center p-6">
  //         <h2 className="text-3xl font-bold mb-10 text-white-500">Oops! No images found</h2>
  //         {/* <h2 className="text-lg font-semibold text-white-600">No images available</h2> */}
  //         <p className="text-white-500">It looks like we don't have any images to show right now. Try refreshing the page or check back later!</p>
  //       </div>
  //     );
  //   }
    

  //   return (
  //     // className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6"
  //     <div className="grid grid-cols-2 gap-4 md:grid-cols-2 lg:grid-cols-2 p-4">
  //       {imageGallery?.data
  //         .slice(0, -1)
  //         .map((image, index) => (

  //           <div
  //             className="relative group rounded-lg shadow-lg overflow-hidden transform transition-transform hover:scale-105"
  //             key={index}
  //           >
  //             {/* Image */}
  //             <div className="flex items-center justify-center w-full h-full">
  //               <img
  //                 className="object-cover object-center w-full h-full"
  //                 src={image.url} // Provide a default image
  //                 // src={image.url || "default-thumbnail.jpg"} // Provide a default image
  //                 alt={image.id || "Untitled Image"} // Provide an alt text
  //               />
  //             </div>
  //           </div>
  //         ))}
  //     </div>
  //   );
  // };


  return (
    <div className={`min-h-screen flex items-center justify-center transition-all duration-1000 bg-gradient-to-br ${getBackgroundColor()}`}>
      {floatingEmojis.map(({ id, emoji, style }) => (
        <FloatingEmoji key={id} emoji={emoji} style={style} />
      ))}
     
      <div className="w-full max-w-6xl bg-white/90 backdrop-blur rounded-lg shadow-xl transition-transform duration-500 hover:shadow-lg">
        <div className="p-6 border-b border-gray-100">
          <div className="text-center flex items-center justify-center gap-2">
            {!submitted && (
              <span className="animate-bounce">
                {questions[currentQuestion].icon}
              </span>
            )}
            <span className="text-2xl font-bold">
              {submitted ? (
                <span className="flex items-center gap-2">
                  <Sparkles className="animate-spin" />
                  Thank You!
                  <Sparkles className="animate-spin" />
                </span>
              ) : "Style Quiz"}
            </span>
          </div>
        </div>
       
        <div className="p-6">

          {!submitted ? (
            <div className={`space-y-6 transition-all duration-500 transform ${
              isTransitioning ? 'opacity-0 scale-95' : 'opacity-100 scale-100'
            }`}>
              <div className="space-y-2">
                <h2 className="text-xl font-medium text-center">
                  {questions[currentQuestion].question}

                </h2>
                <p className="text-gray-500 text-center text-sm">
                  {questions[currentQuestion].subtext}

                </p>
              </div>
              {renderInputField()}
              <div className="flex items-center justify-between mt-8">
                <button
                  onClick={handlePrevious}
                  disabled={currentQuestion === 0}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-300
                    ${currentQuestion === 0
                      ? 'text-gray-300 cursor-not-allowed'
                      : 'text-gray-600 hover:bg-gray-100 hover:scale-105'}`}
                >
                  <ChevronLeft className="w-4 h-4" />
                  Previous
                </button>
               
                <div className="flex gap-1">
                  {questions.map((_, idx) => (
                    <div
                      key={idx}
                      className={`w-2 h-2 rounded-full transition-all duration-500 ${
                        idx === currentQuestion
                          ? 'bg-purple-500 w-6'
                          : idx < currentQuestion
                            ? 'bg-purple-300'
                            : 'bg-gray-200'
                      }`}
                    />
                  ))}
                </div>
                <div className="w-20 text-right">
                  <span className="text-sm text-gray-500">
                    {currentQuestion + 1}/{questions.length}
                  </span>
                </div>
              </div>
              {/* Loader */}
              {isLoading && (
                <div className="fixed inset-0 flex items-center justify-center bg-gray-900 bg-opacity-50 z-50">
                  <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                </div>
              )}
            </div>
          ) : !loadedImages ? (
            <TimerComponent />
          ): (
            <div>
              <h2 className="text-3xl font-bold mb-10 text-white-500">
                {/* Discover Your Personalized Collection! */}
                Your Exclusive Collection Starts Here!
              </h2>
                <FinalImageGallery imageGallery={imageGallery}/>
                <GetOutfitForm image_urls={imageUrls}/>
            </div>
          )}
        </div>
      </div>


      <style jsx global>{`
        @keyframes float {
          0% { transform: translateY(0) rotate(0deg); }
          50% { transform: translateY(-100px) rotate(180deg); }
          100% { transform: translateY(-200px) rotate(360deg); }
        }
       
        @keyframes slideInLeft {
          from { opacity: 0; transform: translateX(-100px); }
          to { opacity: 1; transform: translateX(0); }
        }
       
        @keyframes slideInRight {
          from { opacity: 0; transform: translateX(100px); }
          to { opacity: 1; transform: translateX(0); }
        }
       
        @keyframes slideInBottom {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
       
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        .animate-float { animation: float 3s linear infinite; }
        .animate-slideInLeft { animation: slideInLeft 0.5s ease-out forwards; }
        .animate-slideInRight { animation: slideInRight 0.5s ease-out forwards; }
        .animate-slideInBottom { animation: slideInBottom 0.5s ease-out forwards; }
        .animate-fadeIn { animation: fadeIn 0.3s ease-out forwards; }
      `}</style>
    </div>
  );
};

export default NewDynamicForm;