import React from "react";

const ImageGallery = ({ imageGallery }) => {
  return (
    <div>
      {imageGallery.map((imageData, dataIndex) => (
        <div
          className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-3 py-2"
          key={dataIndex}
        >
          {imageData.similar_products.map((image, index) => (
            <div
              className="relative group bg-gradient-to-br from-purple-100 to-blue-100 rounded-lg shadow-lg overflow-hidden transform transition-transform hover:scale-105"
              key={index}
            >
              <a
                href={image.product_url || "#"}
                target="_blank"
                rel="noopener noreferrer"
              >
                {/* Image Section */}
                <div className="flex items-center justify-center bg-gradient-to-br from-purple-100 to-blue-100">
                  <img
                    className="object-cover object-center"
                    src={image.image_url || "default-thumbnail.jpg"} // Default image
                    alt={image.title || "Untitled Image"} // Alt text fallback
                  />
                </div>
                {/* Title Section */}
                <div className="p-4">
                  <h3 className="text-lg font-semibold group-hover:text-purple-500 transition-colors duration-300">
                    {image.title || "No Title Available"}
                  </h3>
                </div>
                {/* Hover Overlay */}
                <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <span className="font-bold text-lg">
                    View Details
                  </span>
                </div>
              </a>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
};

export default ImageGallery;
