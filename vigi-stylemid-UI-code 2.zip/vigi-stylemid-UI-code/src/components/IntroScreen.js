// src/components/IntroScreen.js

import React from 'react';
import { motion } from 'framer-motion';

const IntroScreen = ({ onLaunch }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 1 }}
      className="min-h-screen flex items-center justify-center transition-all duration-1000 bg-gradient-to-br from-purple-100 to-blue-100"
    >
      <div className="text-center space-y-6 p-8 bg-opacity-80 rounded-lg from-purple-100 to-blue-100">
        <h1 className="text-4xl font-bold">Zukino StyleMind</h1>
        <p className="text-lg">
          Your style partner powered by AI. Upload your image and customize your look!
        </p>
        <button
          onClick={onLaunch}
          className="bg-button-gradient hover:bg-button-gradient-hv text-white font-semibold px-6 py-3 rounded shadow-md transition duration-300 transform hover:scale-105 focus:outline-none"
        >
          Launch App
        </button>
      </div>
    </motion.div>
  );
};

export default IntroScreen;
