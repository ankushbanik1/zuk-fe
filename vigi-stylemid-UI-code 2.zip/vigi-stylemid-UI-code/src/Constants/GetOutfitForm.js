import React, { useState } from 'react';
// import { motion, AnimatePresence } from 'framer-motion';
import axios from 'axios';
import { ChevronRight, ChevronLeft, Check, HeartHandshake } from 'lucide-react';
import ImageGallery from '../components/ImageGallery';

const questions = [
  {
    question: "Did you like our service?",
    subtext: "Your feedback is most valuable to us.",
    type: "options",
    icon: <HeartHandshake className="w-6 h-6" />,
    options: [
      { label: "Liked It", value: "like", icon: "👍" },
      { label: "Dislike", value: "dislike", icon: "👎" },
    ],
  },
];

const FloatingEmoji = ({ emoji, style }) => (
  <div
    className="absolute animate-float opacity-20 pointer-events-none"
    style={style}
  >
    {emoji}
  </div>
);

const GetOutfitForm = ({ image_urls }) => {

  const Get_Ranked_Product_url=process.env.REACT_APP_Get_Ranked_Product_url
  const Client_Id=process.env.REACT_APP_Client_Id

  const [currentQuestion, setCurrentQuestion] = useState(0);  
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false); // State to track submission status
  const [Loading, setLoading] = useState(false); // State to track submission status
  const [imageGallery, setImageGallery] = useState([]);
  const [floatingEmojis, setFloatingEmojis] = useState([]);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [selectedOption, setSelectedOption] = useState(null);

  const handleAnswerChange = (e) => {
    const value = e.target.type === "file" ? e.target.files[0] : e.target.value;
    setAnswers({
      ...answers,
      [currentQuestion]: value,
    });
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      handleSubmit(); // Call the submit function on the last question
    }
  };

  const addFloatingEmoji = (emoji) => {
    const newEmoji = {
      id: Date.now(),
      emoji,
      style: {
        left: `${Math.random() * 80 + 10}%`,
        top: `${Math.random() * 80 + 10}%`,
        fontSize: `${Math.random() * 20 + 20}px`,
        animation: `float ${Math.random() * 3 + 2}s linear infinite`,
      }
    };
    setFloatingEmojis(prev => [...prev, newEmoji]);
    setTimeout(() => {
      setFloatingEmojis(prev => prev.filter(e => e.id !== newEmoji.id));
    }, 3000);
  };

  const handleOptionClick = (value, icon) => {
    setSelectedOption(value);
    setAnswers({ ...answers, [currentQuestion]: value });
    addFloatingEmoji(icon);
   
    setTimeout(() => {
      if (currentQuestion < questions.length - 1) {
        setIsTransitioning(true);
        setTimeout(() => {
          setCurrentQuestion(currentQuestion + 1);

          setSelectedOption(null);
          setIsTransitioning(false);
        }, 500);
      } else {
        setSubmitted(true);
        handleSubmit();
      }
    }, 800);
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setIsTransitioning(true);
      setTimeout(() => {
        setCurrentQuestion(currentQuestion - 1);
        setSelectedOption(answers[currentQuestion - 1] || null);

        setIsTransitioning(false);
      }, 500);
    }
  };

  // const formDataQuestions = ["file", "email", "feedback"]

  const handleSubmit = async () => {
    const formData_img_1 = new FormData();
    const formData_img_2 = new FormData();
    formData_img_1.append("client_id", Client_Id);
    formData_img_2.append("client_id", Client_Id);
    formData_img_1.append("image_url", image_urls[0]);
    formData_img_2.append("image_url", image_urls[1]);

    const MIN_LOADING_TIME = 20000; // Minimum time to show the spinner (in milliseconds)
    const startTime = Date.now();

    const imagedata = []
    // setImageGallery(receivedImageData || []); 

      // Create an array of API calls
    const requests = [
      axios.post(Get_Ranked_Product_url,
        formData_img_1,
          {
            headers: {
              'Content-Type': 'multipart/form-data',
              'STYLEMIND-API-KEY': 'd818a6b2-73d3-4e20-a896-a2ff71f36ce7', // Example for custom header key
            },
          }),
      axios.post(Get_Ranked_Product_url,
        formData_img_2,
          {
            headers: {
              'Content-Type': 'multipart/form-data',
              'STYLEMIND-API-KEY': 'd818a6b2-73d3-4e20-a896-a2ff71f36ce7', // Example for custom header key
            },
          })
    ];

    try {
      setLoading(true);
      // Use Promise.all to execute all requests concurrently
      const responses = await Promise.all(requests);
      // console.log(responses[0]);
      

      // Handle the responses
      responses.forEach((response, index) => {
        // console.log(`Response ${index + 1}:`, response.data);
        if (response.status === 204) {
          // setLoading(false);
          alert("Your outfit search limit is over. Please contact us at founders@stylemind.zukino.co.in for more searches.");
          return;
        }
        if (response.status >= 200 && response.status < 300) {
            // Success
            console.log("Submitted");
            imagedata[index] = JSON.parse(response.data);
            // console.log(imagedata);
            setImageGallery(imagedata || []); // Assuming the response contains an "images" array
            // console.log("Request ID:", image_data);
            setSubmitted(true);

        } else if (response.status >= 400 && response.status < 500) {
            // Client error
            console.error("Client error:", response.status, response.statusText);
        } else if (response.status >= 500) {
            // Server error
            console.error("Server error:", response.status, response.statusText);
        } else {
            // Other responses
            console.warn("Unexpected response:", response.status, response.statusText);
        }
      }
    );
    } catch (error) {
      // Handle network errors or other unexpected issues
      if (error.response) {
          // Server responded with a status code out of the 2xx range
          console.error("Error response:", error.response.status, error.response.data);
      } else if (error.request) {
          // No response received from server
          console.error("No response received:", error.request);
      } else {
          // Error setting up the request
          console.error("Error setting up request:", error.message);
      }
    }  finally {
      const elapsedTime = Date.now() - startTime;
      const remainingTime = MIN_LOADING_TIME - elapsedTime;

      if (remainingTime > 0) {
          setTimeout(() => {
              setLoading(false); // End the loading state after minimum loading time
          }, remainingTime);
      } else {
          setLoading(false); // End loading immediately if elapsed time is greater than the minimum
      }
  }
  };

  const renderInputField = () => {
    const current = questions[currentQuestion];
    if (current.type === "options") {
      return (
        <div className="grid grid-cols-2 gap-4">
          {questions[currentQuestion].options.map((option, index) => {

            const isSelected = selectedOption === option.value;
            return (
              <button
                key={index}
                onClick={() => handleOptionClick(option.value, option.icon)}

                className={`group relative p-6 rounded-xl shadow-sm
                  ${isSelected
                    ? 'bg-purple-100 ring-2 ring-purple-500 animate-pulse'
                    : 'bg-gray-50 hover:bg-gray-100'
                  }
                  transition-all duration-300 transform hover:scale-105 hover:shadow-md
                  ${index % 2 === 0 ? 'animate-slideInLeft' : 'animate-slideInRight'}`}
                style={{
                  animationDelay: `${index * 100}ms`,
                }}
              >
                <div className="text-center space-y-3">
                  <div className={`text-4xl mb-2 transform transition-transform duration-300 ${
                    isSelected ? 'scale-110' : 'group-hover:scale-110'
                  }`}>
                    {option.icon}
                  </div>
                  <span className="text-sm font-medium">{option.label}</span>

                  {isSelected && (
                    <div className="absolute top-2 right-2 animate-fadeIn">
                      <Check className="w-5 h-5 text-purple-500" />
                    </div>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      );
    } else if (current.type === "text") {
      return (
        <div className='flex justify-spacebetween items-center mt-6'>
          <input
            type="text"
            value={answers[currentQuestion] || ""}
            onChange={handleAnswerChange}
            className="px-4 py-3 rounded-lg text-white border border-blue-100 focus:border-purple-300 transition-all duration-300 focus:outline-none shadow-md hover:shadow-lg w-full"
            placeholder="Type your answer"
          />
          <button
            onClick={handleNext}
            disabled={!isAnswered}
            className={`flex items-center gap-2 px-4 py-2 m-4 rounded-lg transition-all duration-300
              ${currentQuestion === 0 && isAnswered
                ? 'text-gray-300 cursor-not-allowed'
                : 'text-gray-600 hover:bg-gray-100 hover:scale-105'}`}
          >
            {currentQuestion < questions.length - 1 ? "Next" : "Submit"}
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      );
    }
  };


  const isAnswered = answers[currentQuestion];

  return (
    <div id="get-outfit">
      {floatingEmojis.map(({ id, emoji, style }) => (
        <FloatingEmoji key={id} emoji={emoji} style={style} />
      ))}
     
      <div className="w-full max-w-6xl bg-white/90 backdrop-blur rounded-lg shadow-xl transition-transform duration-500 hover:shadow-lg">
        <div className="p-6 border-b border-gray-100">
          <div className="text-center flex items-center justify-center gap-2">
            {!submitted && (
              <span className="animate-bounce">
                {questions[currentQuestion].icon}
              </span>
            )}
          </div>
        </div>
       
        <div className="p-6">

          {!submitted ? (
            <div className={`space-y-6 transition-all duration-500 transform ${
              isTransitioning ? 'opacity-0 scale-95' : 'opacity-100 scale-100'
            }`}>
              <div className="space-y-2">
                <h2 className="text-xl font-medium text-center">
                  {questions[currentQuestion].question}

                </h2>
                <p className="text-gray-500 text-center text-sm">
                  {questions[currentQuestion].subtext}

                </p>
              </div>
              {renderInputField()}
              <div className="flex items-center justify-between mt-8">
                <button
                  onClick={handlePrevious}
                  disabled={currentQuestion === 0}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-300
                    ${currentQuestion === 0
                      ? 'text-gray-300 cursor-not-allowed'
                      : 'text-gray-600 hover:bg-gray-100 hover:scale-105'}`}
                >
                  <ChevronLeft className="w-4 h-4" />
                  Previous
                </button>
               
                <div className="flex gap-1">
                  {questions.map((_, idx) => (
                    <div
                      key={idx}
                      className={`w-2 h-2 rounded-full transition-all duration-500 ${
                        idx === currentQuestion
                          ? 'bg-purple-500 w-6'
                          : idx < currentQuestion
                            ? 'bg-purple-300'
                            : 'bg-gray-200'
                      }`}
                    />
                  ))}
                </div>
                <div className="w-20 text-right">
                  <span className="text-sm text-gray-500">
                    {currentQuestion + 1}/{questions.length}
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <div>
              <h2 className="text-3xl font-bold mb-10 text-white-500">
                {/* Discover Your Personalized Collection! */}
                Your Exclusive Collection Starts Here!
              </h2>
                {/* Loader */}
                {Loading ? (
                <div className="fixed inset-0 flex items-center justify-center bg-gray-900 bg-opacity-50 z-50">
                  <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                </div>
                ):(
                  <div>                    
                    <ImageGallery imageGallery={imageGallery} />
                    {/* <ImageGallery imageGallery={imageGallery} /> */}
                  </div>
                )
                }
            </div>
          )}
        </div>
      </div>


      <style jsx global>{`
        @keyframes float {
          0% { transform: translateY(0) rotate(0deg); }
          50% { transform: translateY(-100px) rotate(180deg); }
          100% { transform: translateY(-200px) rotate(360deg); }
        }
       
        @keyframes slideInLeft {
          from { opacity: 0; transform: translateX(-100px); }
          to { opacity: 1; transform: translateX(0); }
        }
       
        @keyframes slideInRight {
          from { opacity: 0; transform: translateX(100px); }
          to { opacity: 1; transform: translateX(0); }
        }
       
        @keyframes slideInBottom {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
       
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        .animate-float { animation: float 3s linear infinite; }
        .animate-slideInLeft { animation: slideInLeft 0.5s ease-out forwards; }
        .animate-slideInRight { animation: slideInRight 0.5s ease-out forwards; }
        .animate-slideInBottom { animation: slideInBottom 0.5s ease-out forwards; }
        .animate-fadeIn { animation: fadeIn 0.3s ease-out forwards; }
      `}</style>
    </div>
  );
};


//   return (
//     <section id="get-outfit">
//       <motion.div
//         initial={{ opacity: 0, scale: 0.9 }}
//         animate={{ opacity: 1, scale: 1 }}
//         transition={{ duration: 0.5 }}
//         // "min-h-screen flex items-center justify-center transition-all duration-1000 bg-gradient-to-br from-purple-100 to-blue-100"
//         className="min-h-screen flex items-center justify-center transition-all duration-1000 bg-gradient-to-br from-purple-100 to-blue-100"
//       >
//         <div id="get-outfit" className="bg-opacity-80 rounded-lg">
//           <AnimatePresence mode="wait">
//             <motion.div
//               key={currentQuestion}
//               initial={{ opacity: 0, x: direction === 1 ? 100 : -100 }}
//               animate={{ opacity: 1, x: 0 }}
//               exit={{ opacity: 0, x: direction === 1 ? -100 : 100 }}
//               transition={{ duration: 0.5 }}
//               className="flex flex-col space-y-6"
//             >
//               {!submitted ? (
//                 <>
//                 <h2 className="text-2xl font-semibold text-center text-white-200 mb-4">
//                   {questions[currentQuestion].question}
//                 </h2>
                
//                 {renderQuestionField()}

//                 <div className="flex justify-between items-center mt-6">
//                   {currentQuestion > 0 && (
//                     <button
//                       onClick={handleBack}
//                       className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded shadow-md transition duration-300 ease-in-out transform hover:-translate-y-1 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:ring-opacity-50"
//                     >
//                       Back
//                     </button>
//                   )}
//                   <button
//                     onClick={handleNext}
//                     disabled={!isAnswered}
//                     className={`px-4 py-2 rounded shadow-md transition duration-300 ease-in-out transform hover:-translate-y-1 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:ring-opacity-50 ml-auto ${
//                       isAnswered
//                         ? "bg-purple-500 hover:bg-purple-600 text-white"
//                         : "bg-gray-500 text-gray-300 cursor-not-allowed"
//                     }`}
//                   >
//                     {currentQuestion < questions.length - 1 ? "Next" : "Submit"}
//                   </button>
//                 </div>
//                 </>
//               ) : (
//                 <div>
//                   <h2 className="text-3xl font-bold mb-10 text-white-500">
//                     {/* Discover Your Personalized Collection! */}
//                     Your Exclusive Collection Starts Here!
//                   </h2>
//                   {Loading ? (
//                     <p>Loading...</p>
//                   ) : (
//                     renderImageGallery()
//                   )}
//                 </div>
//               )}  
//             </motion.div>
//           </AnimatePresence>
//         </div>
//       </motion.div>
//     </section>
//   );
// };

export default GetOutfitForm;
